import { useState } from 'react';

export default function App() {
  const [step, setStep] = useState(0);

  const slides = [
    {
      title: 'Bronson Family Farm',
      text: 'A Living Workforce + Food System',
      bg: 'linear-gradient(135deg, #2f6b3a, #7fb77e)',
    },
    {
      title: 'One Ecosystem',
      text: 'Bronson Family Farm, Farm & Family Alliance, and Parker Farms working together.',
      bg: 'linear-gradient(135deg, #365c7d, #6c9bcf)',
    },
    {
      title: 'Youth Workforce',
      text: 'Real work. Real responsibility.',
      bg: 'linear-gradient(135deg, #5a7f2b, #b7d36a)',
    },
    {
      title: 'The Land',
      text: 'This is where it happens.',
      bg: 'linear-gradient(135deg, #6b4f2a, #c89b5e)',
    },
    {
      title: 'Marketplace',
      text: 'Live and accepting orders.',
      bg: 'linear-gradient(135deg, #7d4b1f, #d89a4a)',
      link: 'https://grownby.com/farms/bronson-family-farm/shop',
    },
    {
      title: 'Roles',
      text: 'People move through this system.',
      bg: 'linear-gradient(135deg, #4a4a7d, #9898d6)',
    },
    {
      title: 'Capabilities',
      text: 'Live feed, QR check-in, weather, marketplace.',
      bg: 'linear-gradient(135deg, #2a6b68, #72c7c2)',
    },
    {
      title: 'May 16 Event',
      text: 'Growers Supply Market.',
      bg: 'linear-gradient(135deg, #7d2a3f, #d67895)',
    },
    {
      title: 'Now Scaling',
      text: 'This is already working. Now we expand.',
      bg: 'linear-gradient(135deg, #1f5f2b, #b7d9a8)',
    },
  ];

  const current = slides[step];

  return (
    <div style={styles.page}>
      <div style={{ ...styles.hero, background: current.bg }}>
        <div style={styles.overlay} />
        <div style={styles.content}>
          <div style={styles.eyebrow}>Bronson Family Farm</div>
          <h1 style={styles.title}>{current.title}</h1>
          <p style={styles.text}>{current.text}</p>

          {current.link && (
            <a
              href={current.link}
              target="_blank"
              rel="noreferrer"
              style={styles.cta}
            >
              Open Marketplace
            </a>
          )}

          <div style={styles.nav}>
            <button
              style={styles.secondary}
              onClick={() => setStep((s) => Math.max(0, s - 1))}
            >
              Back
            </button>

            <button
              style={styles.primary}
              onClick={() =>
                setStep((s) => (s === slides.length - 1 ? 0 : s + 1))
              }
            >
              {step === slides.length - 1 ? 'Restart' : 'Next'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  page: {
    minHeight: '100vh',
    background: '#edf5ea',
    padding: 20,
    fontFamily: 'Arial, sans-serif',
  },
  hero: {
    minHeight: 'calc(100vh - 40px)',
    borderRadius: 28,
    position: 'relative',
    overflow: 'hidden',
    boxShadow: '0 24px 60px rgba(0,0,0,0.12)',
  },
  overlay: {
    position: 'absolute',
    inset: 0,
    background: 'rgba(0,0,0,0.32)',
  },
  content: {
    position: 'absolute',
    left: 40,
    right: 40,
    bottom: 40,
    color: 'white',
  },
  eyebrow: {
    fontSize: 14,
    letterSpacing: '0.08em',
    textTransform: 'uppercase',
    fontWeight: 700,
    marginBottom: 12,
  },
  title: {
    margin: 0,
    fontSize: 52,
    lineHeight: 1.05,
  },
  text: {
    marginTop: 16,
    marginBottom: 0,
    fontSize: 24,
    lineHeight: 1.5,
    maxWidth: 760,
  },
  cta: {
    display: 'inline-block',
    marginTop: 20,
    padding: '14px 20px',
    borderRadius: 12,
    background: '#1f5f2b',
    color: 'white',
    textDecoration: 'none',
    fontWeight: 700,
  },
  nav: {
    marginTop: 28,
    display: 'flex',
    gap: 16,
    alignItems: 'center',
  },
  primary: {
    padding: '14px 18px',
    borderRadius: 12,
    border: 'none',
    background: '#ffffff',
    color: '#1f5f2b',
    fontWeight: 700,
    cursor: 'pointer',
  },
  secondary: {
    padding: '14px 18px',
    borderRadius: 12,
    border: '1px solid rgba(255,255,255,0.4)',
    background: 'rgba(255,255,255,0.12)',
    color: 'white',
    fontWeight: 700,
    cursor: 'pointer',
  },
};
